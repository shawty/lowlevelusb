﻿namespace MadeInTheUSB.FT232H.Console
{
    public class GpioSpiDevice : GpioSpiDeviceBaseClass
    {
        public GpioSpiDevice(MpsseSpiConfig spiConfig) : base(spiConfig)
        {
        }
    }
}
