
DynamicSugar:
	See https://github.com/fredericaltorres/DynamicSugarNet
