﻿namespace FT4232H_UART
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.btnSTART = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.chkRepeat = new System.Windows.Forms.CheckBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.chkEEPROM = new System.Windows.Forms.CheckBox();
            this.chkAB = new System.Windows.Forms.CheckBox();
            this.chkCD = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkPIN = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtOutput
            // 
            this.txtOutput.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtOutput.Font = new System.Drawing.Font("PMingLiU", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtOutput.Location = new System.Drawing.Point(14, 21);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.Size = new System.Drawing.Size(316, 437);
            this.txtOutput.TabIndex = 0;
            // 
            // btnSTART
            // 
            this.btnSTART.Font = new System.Drawing.Font("PMingLiU", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnSTART.Location = new System.Drawing.Point(378, 404);
            this.btnSTART.Name = "btnSTART";
            this.btnSTART.Size = new System.Drawing.Size(104, 38);
            this.btnSTART.TabIndex = 1;
            this.btnSTART.Text = "START";
            this.btnSTART.UseVisualStyleBackColor = true;
            this.btnSTART.Click += new System.EventHandler(this.btnSTART_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(350, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Test Result";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("PMingLiU", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblResult.ForeColor = System.Drawing.Color.Red;
            this.lblResult.Location = new System.Drawing.Point(342, 80);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(0, 64);
            this.lblResult.TabIndex = 5;
            // 
            // chkRepeat
            // 
            this.chkRepeat.AutoSize = true;
            this.chkRepeat.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkRepeat.Location = new System.Drawing.Point(353, 370);
            this.chkRepeat.Name = "chkRepeat";
            this.chkRepeat.Size = new System.Drawing.Size(100, 20);
            this.chkRepeat.TabIndex = 6;
            this.chkRepeat.Text = "Repeat Test";
            this.chkRepeat.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // chkEEPROM
            // 
            this.chkEEPROM.AutoSize = true;
            this.chkEEPROM.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkEEPROM.Location = new System.Drawing.Point(353, 318);
            this.chkEEPROM.Name = "chkEEPROM";
            this.chkEEPROM.Size = new System.Drawing.Size(144, 20);
            this.chkEEPROM.TabIndex = 7;
            this.chkEEPROM.Text = "Program EEPROM";
            this.chkEEPROM.UseVisualStyleBackColor = true;
            // 
            // chkAB
            // 
            this.chkAB.AutoSize = true;
            this.chkAB.Location = new System.Drawing.Point(10, 35);
            this.chkAB.Name = "chkAB";
            this.chkAB.Size = new System.Drawing.Size(123, 16);
            this.chkAB.TabIndex = 8;
            this.chkAB.Text = "Test PortA and PortB";
            this.chkAB.UseVisualStyleBackColor = true;
            this.chkAB.CheckedChanged += new System.EventHandler(this.chkAB_CheckedChanged);
            // 
            // chkCD
            // 
            this.chkCD.AutoSize = true;
            this.chkCD.Location = new System.Drawing.Point(10, 57);
            this.chkCD.Name = "chkCD";
            this.chkCD.Size = new System.Drawing.Size(123, 16);
            this.chkCD.TabIndex = 9;
            this.chkCD.Text = "Test PortC and PortD";
            this.chkCD.UseVisualStyleBackColor = true;
            this.chkCD.CheckedChanged += new System.EventHandler(this.chkCD_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkAB);
            this.groupBox1.Controls.Add(this.chkCD);
            this.groupBox1.Location = new System.Drawing.Point(349, 222);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(158, 80);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Port Test";
            // 
            // chkPIN
            // 
            this.chkPIN.AutoSize = true;
            this.chkPIN.Font = new System.Drawing.Font("PMingLiU", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.chkPIN.Location = new System.Drawing.Point(353, 344);
            this.chkPIN.Name = "chkPIN";
            this.chkPIN.Size = new System.Drawing.Size(160, 20);
            this.chkPIN.TabIndex = 11;
            this.chkPIN.Text = "Check RI / DCD pins";
            this.chkPIN.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 470);
            this.Controls.Add(this.chkPIN);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.chkEEPROM);
            this.Controls.Add(this.chkRepeat);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSTART);
            this.Controls.Add(this.txtOutput);
            this.Name = "Form1";
            this.Text = "FT4232H UART AP ver1.0";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Button btnSTART;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.CheckBox chkRepeat;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox chkEEPROM;
        private System.Windows.Forms.CheckBox chkAB;
        private System.Windows.Forms.CheckBox chkCD;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkPIN;
    }
}

