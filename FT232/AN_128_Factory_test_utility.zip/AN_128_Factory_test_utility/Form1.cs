﻿// Copyright (c) 2009  Future Technology Devices International Ltd.
//
// Module Name
//
//     FT4232H_UART test application
//
// Abstract:
//
//    C# windows form program, 
//    this is a sample code to test the UART interface function for FT4232H device.
//    this application can only connect port A & port B, and port C & port D for test. you cannot connect any two ports for test.
//
//    there are five options in this application,they are:
//       Test PortA and PortB : check it if you want to test UART data transfer between port A and port B
//       Test PortC and PortD : check it if you want to test UART data transfer between port C and port D
//       Program EEPROM : check it if you want to program EEPROM
//       Check RI / CDC pins : check it if you want to test RI & CDC pins
//       Repeat Test : check it if you want to do endless test
//
// Revision History:
//
//    08/09/2009    first released
//


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using FTD2XX_NET; //load our dll file
using System.Runtime.InteropServices;




namespace FT4232H_UART
{

    public partial class Form1 : Form
    {
        //**************************************************************************
        //
        // FUNCTION IMPORTS FROM FTD2XX DLL
        //
        //**************************************************************************

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_OpenEx(string pvArg1, int dwFlags, ref IntPtr ftHandle);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_Close(IntPtr ftHandle);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_SetBaudRate(IntPtr ftHandle, int dwBaudRate);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_SetDataCharacteristics(IntPtr ftHandle, byte uWordLength,byte uStopBits, byte uParity);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_SetFlowControl(IntPtr ftHandle, ushort usFlowControl, byte uXon, byte uXoff);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_SetTimeouts(IntPtr ftHandle, int dwReadTimeout, int dwWriteTimeout);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_GetQueueStatus(IntPtr ftHandle, ref int lpdwAmountInRxQueue);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_Purge(IntPtr ftHandle, byte uEventCh);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_Read(IntPtr ftHandle, byte[] lpBuffer, int dwBytesToRead,ref int lpdwBytesReturned);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_Write(IntPtr ftHandle, byte[] lpBuffer, int dwBytesToWrite,ref int lpdwBytesWritten);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_SetDtr(IntPtr ftHandle);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_ClrDtr(IntPtr ftHandle);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_SetRts(IntPtr ftHandle);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_ClrRts(IntPtr ftHandle);

        [DllImportAttribute("ftd2xx.dll", CallingConvention = CallingConvention.Cdecl)]
        static extern FTDI.FT_STATUS FT_GetModemStatus(IntPtr ftHandle, ref byte ModemStatus);

        //======================================
        // FT_OpenEx Flags
        //======================================
        const byte FT_OPEN_BY_SERIAL_NUMBER = 1;
        const byte FT_OPEN_BY_DESCRIPTION = 2;
        const byte FT_OPEN_BY_LOCATION = 4;

        //======================================
        // Stop Bits
        //======================================
        const byte FT_STOP_BITS_1 = 0;		
        const byte FT_STOP_BITS_1_5	= 1;
        const byte FT_STOP_BITS_2 = 2;		

        //======================================
        // Parity
        //======================================
        const byte FT_PARITY_NONE = 0;		
        const byte FT_PARITY_ODD = 1;		
        const byte FT_PARITY_EVEN = 2;		
        const byte FT_PARITY_MARK = 3;		
        const byte FT_PARITY_SPACE = 4;		

        //======================================
        // Flow Control
        //======================================
        const int FT_FLOW_NONE = 0x0000;
        const int FT_FLOW_RTS_CTS = 0x0100;
        const int FT_FLOW_DTR_DSR = 0x0200;
        const int FT_FLOW_XON_XOFF = 0x0400;

        const int TRANSFERBYTE = 256;//data size of transfer data
        byte[] WriteBuf = new byte[TRANSFERBYTE];
        byte[] ReadBuf = new byte[TRANSFERBYTE];
        uint ftdiDeviceCount = 0;
        FTDI.FT_STATUS ftStatus = FTDI.FT_STATUS.FT_OK;
        static int UARTStep = 0;
        IntPtr HandleA = IntPtr.Zero, HandleB = IntPtr.Zero, HandleC = IntPtr.Zero, HandleD = IntPtr.Zero;
        bool PassFlag = true;
        const int MaxTimer1Step = 15;

        
        public Form1()
        {
            InitializeComponent();
            //initial setting for this application
            this.chkAB.Checked = true;
            this.chkCD.Checked = true;
            this.chkEEPROM.Checked = true;
            for (int i = 0; i < TRANSFERBYTE; i++)
                WriteBuf[i] = (byte)i;
        }

        //=================================================================================================
        // Funtcion Name : btnSTART_Click
        // description : this function will be called after START button is clicked, we start the main flow 
        //               here
        //=================================================================================================
        private void btnSTART_Click(object sender, EventArgs e)
        {
            //clear the meesage and test result 
            lblResult.Text = "";
            txtOutput.Text = "";       

            // Create new instance of the FTDI device class
            FTDI myFtdiDevice = new FTDI();
            //Get Number of Device
            ftStatus = myFtdiDevice.GetNumberOfDevices(ref ftdiDeviceCount);
            if ((ftStatus != FTDI.FT_STATUS.FT_OK) || (ftdiDeviceCount < 4))
                txtOutput.Text = "Cannot detect FT4232H device, please connect it and check again....";
            else if (ftdiDeviceCount != 4)
                txtOutput.Text = "Error!!\r\nPlease make sure there is only one FT4232H device.";
            else
            {
                //Get Device infomation
                FTDI.FT_DEVICE_INFO_NODE[] ftdiDeviceList = new FTDI.FT_DEVICE_INFO_NODE[ftdiDeviceCount];
                ftStatus = myFtdiDevice.GetDeviceList(ftdiDeviceList);

                Boolean IsFT4232H = true; //check FTDI chip is FT4232H or not
                if (ftStatus == FTDI.FT_STATUS.FT_OK)
                {
                    for (int i = 0; i < ftdiDeviceCount; i++)
                    {
                        //judge FTDI chip is FT4232H or not
                        if (ftdiDeviceList[i].Type != FTDI.FT_DEVICE.FT_DEVICE_4232H)
                            IsFT4232H = false;
                    }
                }

                if (IsFT4232H == false)
                    txtOutput.Text = "Error!!\r\nThis is not FT4232H device.";
                else
                {
                    if (chkEEPROM.Checked == true)
                    {
                        // use FTD2XX_NET.dll's API to open port for program EEPROM, then close it.
                        if (myFtdiDevice.OpenBySerialNumber(ftdiDeviceList[0].SerialNumber) == FTDI.FT_STATUS.FT_OK)
                        {
                            WriteEEPROM(myFtdiDevice);
                            myFtdiDevice.Close();
                        }
                    }

                    // our API of FTD2XX_NET only support one port at one time, because we need to open four ports at same time, 
                    // so we need to call FTD2XX's API to get handle for per port.

                    //open device by serial number
                    if (FT_OpenEx(ftdiDeviceList[0].SerialNumber, FT_OPEN_BY_SERIAL_NUMBER, ref HandleA) != FTDI.FT_STATUS.FT_OK)
                        txtOutput.Text += "device open fail...........";

                    if (FT_OpenEx(ftdiDeviceList[1].SerialNumber, FT_OPEN_BY_SERIAL_NUMBER, ref HandleB) != FTDI.FT_STATUS.FT_OK)
                        txtOutput.Text += "device open fail...........";

                    if (FT_OpenEx(ftdiDeviceList[2].SerialNumber, FT_OPEN_BY_SERIAL_NUMBER, ref HandleC) != FTDI.FT_STATUS.FT_OK)
                        txtOutput.Text += "device open fail...........";

                    if (FT_OpenEx(ftdiDeviceList[3].SerialNumber, FT_OPEN_BY_SERIAL_NUMBER, ref HandleD) != FTDI.FT_STATUS.FT_OK)
                        txtOutput.Text += "device open fail...........";
                    else
                    {
                        btnSTART.Enabled = false;//disable START button

                            if ((chkAB.Checked == true) || (chkCD.Checked == true))
                            {
                                //enable timer1 to execute the procedure
                                timer1.Interval = 400;
                                timer1.Start();
                            }
                            else //if we don't check port A <-> port B connection, and we don't check port C <-> port D connection
                                 //that means we don't want to check any connection. So we close all ports here.
                            {
                                lblResult.Text = "";
                                btnSTART.Enabled = true;
                                FT_Close(HandleA);
                                FT_Close(HandleB);
                                FT_Close(HandleC);
                                FT_Close(HandleD);
                            }
                    }

                }
            }
        }

        //=================================================================================================
        // Funtcion Name : timer1_Tick
        // description : this function will be call after timer1 is enabled by timer1.start()
        //               you can config timer1.Interval to decide the calling frequency
        //=================================================================================================
        private void timer1_Tick(object sender, EventArgs e)
        {
            switch(UARTStep)
            {
                case 0://initialize
                    lblResult.Text = "";
                    txtOutput.Text = "Start Data transfer test........\r\n";
                    PassFlag = true;
                    if (chkAB.Checked == true)
                        UARTStep++;
                    else if (chkCD.Checked == true)
                        UARTStep += 8;
                    else
                        UARTStep = MaxTimer1Step;
                break;

                case 1://test DTR,DSR,RTS,CTS pins 
                    if ((UART_PinTest(HandleA, HandleB) == false) || (UART_PinTest(HandleB, HandleA) == false))
                    {
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }
                    else
                        UARTStep++;
                    break;

                case 2://Config port A & port B at 9600 baud
                    txtOutput.Text += "Config port A and port B at 9600 baud........\r\n";
                    if (UARTConfig(HandleA, 9600) != true)
                    {
                        txtOutput.Text += "ERROR! Configure Port A to Baudrate = 9600 fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if (UARTConfig(HandleB, 9600) != true)
                    {
                        txtOutput.Text += "ERROR! Configure Port B to Baudrate = 9600 fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if (PassFlag == true)
                        UARTStep++;
                break;

                case 3://Transfer data from port A to Port B                 
                    txtOutput.Text += "Transfer data from port A to Port B........\r\n";
                    if (UART_Transfer(HandleA, HandleB) != true)
                    {
                        txtOutput.Text += "ERROR! Data transfer from Port A to Port B fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    else
                        UARTStep++;
                break;

                case 4://Transfer data from port B to Port A
                    txtOutput.Text += "Transfer data from port B to Port A........\r\n";
                    if (UART_Transfer(HandleB, HandleA) != true)
                    {
                        txtOutput.Text += "ERROR! Data transfer from Port B to Port A fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    else
                        UARTStep++;
                break;

                case 5://Configure Baudrate of  Port A & Port B
                    txtOutput.Text += "Config port A and port B at 1M baud........\r\n";
                    if (UARTConfig(HandleA, 1000000) != true)
                    {
                        txtOutput.Text += "ERROR! Configure Port A to Baudrate = 1M fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if (UARTConfig(HandleB, 1000000) != true)
                    {
                        txtOutput.Text += "ERROR! Configure Port B to Baudrate = 1M fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if (PassFlag == true)
                        UARTStep++;
                break;

                case 6://Transfer data from port A to Port B
                    txtOutput.Text += "Transfer data from port A to Port B........\r\n";
                    if (UART_Transfer(HandleA, HandleB) != true)
                    {
                        txtOutput.Text += "ERROR! Data transfer from Port A to Port B fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    else
                        UARTStep++;
                break;


                case 7://Transfer data from port B to Port A
                    txtOutput.Text += "Transfer data from port B to Port A........\r\n";
                    if (UART_Transfer(HandleB, HandleA) != true)
                    {
                        txtOutput.Text += "ERROR! Data transfer from Port B to Port A fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if(chkCD.Checked == true)
                        UARTStep++;
                    else
                        UARTStep = MaxTimer1Step;
                break;


                case 8://test DTR,DSR,RTS,CTS pins 
                    if ((UART_PinTest(HandleC, HandleD) == false) || (UART_PinTest(HandleD, HandleC) == false))
                    {
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }
                    else
                        UARTStep++;
                break;

                case 9://Config port C & port D at 9600 baud
                    txtOutput.Text += "Config port C and port D at 9600 baud........\r\n";
                    if (UARTConfig(HandleC, 9600) != true)
                    {
                        txtOutput.Text += "ERROR! Configure Port C to Baudrate = 9600 fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if (UARTConfig(HandleD, 9600) != true)
                    {
                        txtOutput.Text += "ERROR! Configure Port D to Baudrate = 9600 fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if (PassFlag == true)
                        UARTStep++;
                break;

                case 10://Transfer data from port C to Port D                 
                    txtOutput.Text += "Transfer data from port C to Port D........\r\n";
                    if (UART_Transfer(HandleC, HandleD) != true)
                    {
                        txtOutput.Text += "ERROR! Data transfer from Port C to Port D fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    else
                        UARTStep++;
                break;

                case 11://Transfer data from port D to Port C
                    txtOutput.Text += "Transfer data from port D to Port C........\r\n";
                    if (UART_Transfer(HandleD, HandleC) != true)
                    {
                        txtOutput.Text += "ERROR! Data transfer from Port D to Port C fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    else
                        UARTStep++;
                break;

                case 12://Configure Baudrate of  Port C & Port D
                    txtOutput.Text += "Config port C and port D at 1M baud........\r\n";
                    if (UARTConfig(HandleC, 1000000) != true)
                    {
                        txtOutput.Text += "ERROR! Configure Port C to Baudrate = 1M fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if (UARTConfig(HandleD, 1000000) != true)
                    {
                        txtOutput.Text += "ERROR! Configure Port D to Baudrate = 1M fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    if (PassFlag == true)
                        UARTStep++;
                break;

                case 13://Transfer data from port C to Port D                 
                    txtOutput.Text += "Transfer data from port C to Port D........\r\n";
                    if (UART_Transfer(HandleC, HandleD) != true)
                    {
                        txtOutput.Text += "ERROR! Data transfer from Port C to Port D fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    else
                        UARTStep++;
                break;

                case 14://Transfer data from port D to Port C
                    txtOutput.Text += "Transfer data from port D to Port C........\r\n";
                    if (UART_Transfer(HandleD, HandleC) != true)
                    {
                        txtOutput.Text += "ERROR! Data transfer from Port D to Port C fail......\r\n";
                        PassFlag = false;
                        UARTStep = MaxTimer1Step;
                    }

                    else
                        UARTStep++;
                break;

                case 15://show test result and close all handles
                    if ((chkRepeat.Checked == false) || (PassFlag == false))
                    {
                        timer1.Stop();
                        btnSTART.Enabled = true;
#if true
                        FT_Close(HandleA);
                        FT_Close(HandleB);
                        FT_Close(HandleC);
                        FT_Close(HandleD);
#endif
                    }
                    if (PassFlag == true)
                    {
                        txtOutput.Text += "Congratulations, test PASS.";
                        lblResult.Text = "PASS";
                    }
                    else
                        lblResult.Text = "FAIL";

                    UARTStep = 0;
                break;
            }
        }

        //=================================================================================================
        // Funtcion Name : WriteEEPROM
        // description : this function can program EEPROM for FT4232H 
        //=================================================================================================
        void WriteEEPROM(FTDI myFtdiDevice)
        {
            FTDI.FT4232H_EEPROM_STRUCTURE ee4232h = new FTDI.FT4232H_EEPROM_STRUCTURE();
            //don't modify those parameters
            ee4232h.PullDownEnable = false;
            ee4232h.SerNumEnable = true;
            ee4232h.ASlowSlew = false;
            ee4232h.ASchmittInput = false;
            ee4232h.ADriveCurrent = 4;
            ee4232h.BSlowSlew = false;
            ee4232h.BSchmittInput = false;
            ee4232h.BDriveCurrent = 4;
            ee4232h.CSlowSlew = false;
            ee4232h.CSchmittInput = false;
            ee4232h.CDriveCurrent = 4;
            ee4232h.DSlowSlew = false;
            ee4232h.DSchmittInput = false;
            ee4232h.DDriveCurrent = 4;
            ee4232h.ARIIsTXDEN = false;
            ee4232h.BRIIsTXDEN = false;
            ee4232h.CRIIsTXDEN = false;
            ee4232h.DRIIsTXDEN = false;
            ee4232h.AIsVCP = true;
            ee4232h.BIsVCP = true;
            ee4232h.CIsVCP = true;
            ee4232h.DIsVCP = true;
            ee4232h.MaxPower = 200;

            //you can modify the below parameters
            ee4232h.Description = "FT4232H Device";
            ee4232h.Manufacturer = "FTDI";
            ee4232h.ManufacturerID = "FT";
            ee4232h.VendorID = 0x0403;
            ee4232h.ProductID = 0x6011;
            ee4232h.RemoteWakeup = false;
            ee4232h.SelfPowered = false;
            ee4232h.SerialNumber = "FT" + GenSerialNo();//the default serial number is general by current time

            if (myFtdiDevice.WriteFT4232HEEPROM(ee4232h) != FTDI.FT_STATUS.FT_OK)
                txtOutput.Text += "write EEPROM fail\r\n";
            else
                txtOutput.Text += "Program EEPROM OK\r\n";
        }

        //=================================================================================================
        // Funtcion Name : GenSerialNo
        // description : this function generate serial number by transfer current Data & Time 
        //=================================================================================================
        private string GenSerialNo()
        {
            // Serial number has format:-
            //     Prefix:Year:Month:Day:Hour:Minute:Second
            //
            //     pppppppp pppppppp 0yyy yymm mmdd dddh hhhh mmmm mmss ssss
            long LongVal;
            int i, j;
            char[] LoopUp = new char[36];
            string Prefix = "";//declare a null string
            //transfer current date & time to long value
            LongVal = Convert.ToUInt16(DateTime.Now.Year) & 0x1F;
            LongVal *= 16;
            LongVal += (Convert.ToByte(DateTime.Now.Month) & 0x0F);
            LongVal *= 32;
            LongVal += (Convert.ToByte(DateTime.Now.Day) & 0x1F);
            LongVal *= 32;
            LongVal += (Convert.ToByte(DateTime.Now.Hour) & 0x1F);
            LongVal *= 64;
            LongVal += (Convert.ToByte(DateTime.Now.Second) & 0x3F);
            LongVal *= 64;
            LongVal += Convert.ToByte(DateTime.Now.Minute) & 0x3F;
            //create loop up table, put 0~9,A~Z into look up table
            for (i = 0; i < 36; i++)
            {
                j = i;
                if (i > 9)
                    j += 7;
                LoopUp[i] = (char)(j+0x30);

            }
            //convert Long value to serial number which is combine by 0~9 & A~Z;
            for (i = 0; i < 6; i++)
            {
                j = (int)(LongVal % 36);
                LongVal /= 36;
                Prefix = LoopUp[j] + Prefix;
            }

            return Prefix;
        }

        //=================================================================================================
        // Funtcion Name : UARTConfig
        // call this function to config the COM port setting
        //=================================================================================================
        private bool UARTConfig(IntPtr ftHandle, int baudrate)
        {
            bool _result = false;

            if (FT_SetBaudRate(ftHandle, baudrate) == FTDI.FT_STATUS.FT_OK)
                if (FT_SetDataCharacteristics(ftHandle, 8, FT_STOP_BITS_1, FT_PARITY_NONE) == FTDI.FT_STATUS.FT_OK)
                    if (FT_SetFlowControl(ftHandle, FT_FLOW_RTS_CTS, 0x11, 0x13) == FTDI.FT_STATUS.FT_OK)
                        if (FT_SetTimeouts(ftHandle, 500, 500) == FTDI.FT_STATUS.FT_OK)
                            _result = true;                            
            return _result;
        }
        //=================================================================================================
        // Funtcion Name : UART_Transfer
        // call this function to start data transfer
        //=================================================================================================
        private bool UART_Transfer(IntPtr ftHandle_A, IntPtr ftHandle_B)
        {
            int WrittenBytes = 0, ReceivedByte = 0, actualReadByte = 0;
            int i;

            //flush RX & TX buffer
            if (FT_Purge(ftHandle_A, 3) != FTDI.FT_STATUS.FT_OK)
            {
                txtOutput.Text += "FT_Purge portA fail\r\n";
                return false;
            }
            if (FT_Purge(ftHandle_B, 3) != FTDI.FT_STATUS.FT_OK)
            {
                txtOutput.Text += "FT_Purge portB fail\r\n";
                return false;
            }

            //write data to buffer
            if (FT_Write(ftHandle_A, WriteBuf, TRANSFERBYTE, ref WrittenBytes) != FTDI.FT_STATUS.FT_OK)
            {
                txtOutput.Text += "FT_Write fail\r\n";
                return false;
            }

            int LoopCount = 0;
            while (true) //wait here until receive buffer get enough data bytes
            {
                if (FT_GetQueueStatus(ftHandle_B, ref ReceivedByte) == FTDI.FT_STATUS.FT_OK)
                {
                    if (ReceivedByte == TRANSFERBYTE)
                        break;
                }
                Thread.Sleep(2);
                LoopCount++;
                if(LoopCount > 400)
                {
                    txtOutput.Text += "FT_Read timeout\r\n";
                    return false;
                }

            }
            //read data from buffer
            FT_Read(ftHandle_B, ReadBuf, TRANSFERBYTE, ref actualReadByte);
            if (actualReadByte == TRANSFERBYTE)
                //compare receive buffer and write buffer
                for (i = 0; i < TRANSFERBYTE; i++)
                    if (ReadBuf[i] != WriteBuf[i])
                    {
                        txtOutput.Text += "Read data != Write data\r\n";
                        return false;
                    }
               
            return true;
        }

        private void chkAB_CheckedChanged(object sender, EventArgs e)
        {
            if ((chkAB.Checked == false) && (chkCD.Checked == false))
                chkRepeat.Enabled = false;
            else
                chkRepeat.Enabled = true;
        }

        private void chkCD_CheckedChanged(object sender, EventArgs e)
        {
            if ((chkAB.Checked == false) && (chkCD.Checked == false))
                chkRepeat.Enabled = false;
            else
                chkRepeat.Enabled = true;
        }

        //=================================================================================================
        // Funtcion Name : UART_PinTest
        // this function test the connect status of UART pins except RX & TX
        //=================================================================================================
        private bool UART_PinTest(IntPtr portA, IntPtr portB)
        {
            const byte FT_CTS = 16;
            const byte FT_DCD = 128;
            const byte FT_DSR = 32;
            const byte FT_RI = 64;
            byte ModemStatus = 0;

            //
            // PortA set pins status & PortB get pins status
            //
            txtOutput.Text += "UART_PinTest\r\n";
            // PortA set DTR
            FT_SetDtr(portA);
            Thread.Sleep(100);//wait 100ms
            // PortB read DSR
            FT_GetModemStatus(portB, ref ModemStatus);
            if ((ModemStatus & FT_DSR) == 0)
            {
                txtOutput.Text += "Error, DSR should be at high level, but it is in low level now\r\n";
                return false;
            }
            if (chkPIN.Checked == true)
            {
                if ((ModemStatus & FT_DCD) == 0)
                {
                    txtOutput.Text += "Error, DCD should be at high level, but it is in low level now\r\n";
                    return false;
                }
                if ((ModemStatus & FT_RI) == 0)
                {
                    txtOutput.Text += "Error, RI should be at high level, but it is in low level now\r\n";
                    return false;
                }
            }

            // PortA clear DTR
            FT_ClrDtr(portA);
            Thread.Sleep(100);
            // PortB read DSR
            FT_GetModemStatus(portB, ref ModemStatus);
            if ((ModemStatus & FT_DSR) != 0)
            {
                txtOutput.Text += "Error, DSR should be at low level, but it is in high level now\r\n";
                return false;
            }
            if (chkPIN.Checked == true)
            {
                if ((ModemStatus & FT_DCD) != 0)
                {
                    txtOutput.Text += "Error, DCDshould be at low level, but it is in high level now\r\n";
                    return false;
                }
                if ((ModemStatus & FT_RI) != 0)
                {
                    txtOutput.Text += "Error, RI should be at low level, but it is in high level now\r\n";
                    return false;
                }
            }

            // PortA set RTS
            FT_SetRts(portA);
            Thread.Sleep(100);
            // PortB read CTS
            FT_GetModemStatus(portB, ref ModemStatus);
            if ((ModemStatus & FT_CTS) == 0)
            {
                txtOutput.Text += "Error, CTS should be at high level, but it is in low level now\r\n";
                return false;
            }

            // PortA clear RTS
            FT_ClrRts(portA);
            Thread.Sleep(100);
            // PortB read CTS
            FT_GetModemStatus(portB, ref ModemStatus);
            if ((ModemStatus & FT_CTS) != 0)
            {
                txtOutput.Text += "Error, CTS should be at low level, but it is in high level now\r\n";
                return false;
            }

            return true;
        }

    }


}
