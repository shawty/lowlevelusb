libMPSSE-.Net-Wrapper
=====================

A C# wrapper to the FTDI devices library libMPSSE